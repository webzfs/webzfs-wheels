.. hazmat::

Decrepit cryptography
=====================

This module holds old, deprecated, and/or insecure cryptographic
algorithms that may be needed in exceptional cases for backwards
compatibility or interoperability reasons. Unless necessary
their use is **strongly discouraged**.

.. toctree::
    :maxdepth: 2

    ciphers
